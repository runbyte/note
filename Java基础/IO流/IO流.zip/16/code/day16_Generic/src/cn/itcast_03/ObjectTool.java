package cn.itcast_03;

public class ObjectTool {
	private Object obj;

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) { // Object obj = new Integer(30);
		this.obj = obj;
	}
}
