package cn.itcast_02;

public class HashCodeDemo {
	public static void main(String[] args) {
		System.out.println("hello".hashCode());
		System.out.println("hello".hashCode());
		System.out.println("world".hashCode());
	}
}